# RAT Fixture

A small repository for testing RAT metrics.
Second line of the readme.
