import os
import json

from util import add


def main():
    print(add(1, 2))
    return 0
