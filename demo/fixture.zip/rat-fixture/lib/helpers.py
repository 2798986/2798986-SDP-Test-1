def add(a, b):
    return a + b  # sum


def sub(a, b):
    return a - b
